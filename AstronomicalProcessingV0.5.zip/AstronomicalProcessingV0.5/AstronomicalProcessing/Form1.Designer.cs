﻿namespace AstronomicalProcessing
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGetInteractions = new System.Windows.Forms.Button();
            this.ListBoxInteractions = new System.Windows.Forms.ListBox();
            this.btnSortInteractions = new System.Windows.Forms.Button();
            this.ListBoxSort = new System.Windows.Forms.ListBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.TextBoxSearch = new System.Windows.Forms.TextBox();
            this.ListBoxResults = new System.Windows.Forms.ListBox();
            this.GrpBoxEdit = new System.Windows.Forms.GroupBox();
            this.LblNewValue = new System.Windows.Forms.Label();
            this.LblTime = new System.Windows.Forms.Label();
            this.ButtonEdit = new System.Windows.Forms.Button();
            this.TextBoxNewValue = new System.Windows.Forms.TextBox();
            this.TextBoxTime = new System.Windows.Forms.TextBox();
            this.ButtonClearAll = new System.Windows.Forms.Button();
            this.GrpBoxSearch = new System.Windows.Forms.GroupBox();
            this.GrpBoxEdit.SuspendLayout();
            this.GrpBoxSearch.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnGetInteractions
            // 
            this.btnGetInteractions.Location = new System.Drawing.Point(11, 11);
            this.btnGetInteractions.Margin = new System.Windows.Forms.Padding(2);
            this.btnGetInteractions.Name = "btnGetInteractions";
            this.btnGetInteractions.Size = new System.Drawing.Size(102, 51);
            this.btnGetInteractions.TabIndex = 0;
            this.btnGetInteractions.Text = "Neutrino Interactions/hour";
            this.btnGetInteractions.UseVisualStyleBackColor = true;
            this.btnGetInteractions.Click += new System.EventHandler(this.btnGetInteractions_Click);
            // 
            // ListBoxInteractions
            // 
            this.ListBoxInteractions.FormattingEnabled = true;
            this.ListBoxInteractions.Location = new System.Drawing.Point(11, 75);
            this.ListBoxInteractions.Margin = new System.Windows.Forms.Padding(2);
            this.ListBoxInteractions.Name = "ListBoxInteractions";
            this.ListBoxInteractions.Size = new System.Drawing.Size(102, 342);
            this.ListBoxInteractions.TabIndex = 1;
            // 
            // btnSortInteractions
            // 
            this.btnSortInteractions.Location = new System.Drawing.Point(126, 11);
            this.btnSortInteractions.Margin = new System.Windows.Forms.Padding(2);
            this.btnSortInteractions.Name = "btnSortInteractions";
            this.btnSortInteractions.Size = new System.Drawing.Size(102, 51);
            this.btnSortInteractions.TabIndex = 2;
            this.btnSortInteractions.Text = "Sort Neutrino Interactions";
            this.btnSortInteractions.UseVisualStyleBackColor = true;
            this.btnSortInteractions.Click += new System.EventHandler(this.btnSortInteractions_Click);
            // 
            // ListBoxSort
            // 
            this.ListBoxSort.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ListBoxSort.FormattingEnabled = true;
            this.ListBoxSort.Location = new System.Drawing.Point(126, 75);
            this.ListBoxSort.Margin = new System.Windows.Forms.Padding(2);
            this.ListBoxSort.MultiColumn = true;
            this.ListBoxSort.Name = "ListBoxSort";
            this.ListBoxSort.Size = new System.Drawing.Size(102, 342);
            this.ListBoxSort.TabIndex = 3;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(111, 31);
            this.btnSearch.Margin = new System.Windows.Forms.Padding(2);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(102, 20);
            this.btnSearch.TabIndex = 4;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // TextBoxSearch
            // 
            this.TextBoxSearch.Location = new System.Drawing.Point(5, 31);
            this.TextBoxSearch.Margin = new System.Windows.Forms.Padding(2);
            this.TextBoxSearch.Name = "TextBoxSearch";
            this.TextBoxSearch.Size = new System.Drawing.Size(102, 20);
            this.TextBoxSearch.TabIndex = 5;
            // 
            // ListBoxResults
            // 
            this.ListBoxResults.FormattingEnabled = true;
            this.ListBoxResults.Location = new System.Drawing.Point(5, 64);
            this.ListBoxResults.Margin = new System.Windows.Forms.Padding(2);
            this.ListBoxResults.Name = "ListBoxResults";
            this.ListBoxResults.Size = new System.Drawing.Size(102, 147);
            this.ListBoxResults.TabIndex = 7;
            // 
            // GrpBoxEdit
            // 
            this.GrpBoxEdit.Controls.Add(this.LblNewValue);
            this.GrpBoxEdit.Controls.Add(this.TextBoxTime);
            this.GrpBoxEdit.Controls.Add(this.ButtonEdit);
            this.GrpBoxEdit.Controls.Add(this.LblTime);
            this.GrpBoxEdit.Controls.Add(this.TextBoxNewValue);
            this.GrpBoxEdit.Location = new System.Drawing.Point(241, 233);
            this.GrpBoxEdit.Name = "GrpBoxEdit";
            this.GrpBoxEdit.Size = new System.Drawing.Size(220, 107);
            this.GrpBoxEdit.TabIndex = 8;
            this.GrpBoxEdit.TabStop = false;
            this.GrpBoxEdit.Text = "Edit";
            // 
            // LblNewValue
            // 
            this.LblNewValue.AutoSize = true;
            this.LblNewValue.Location = new System.Drawing.Point(12, 48);
            this.LblNewValue.Name = "LblNewValue";
            this.LblNewValue.Size = new System.Drawing.Size(62, 13);
            this.LblNewValue.TabIndex = 6;
            this.LblNewValue.Text = "New Value:";
            // 
            // LblTime
            // 
            this.LblTime.AutoSize = true;
            this.LblTime.Location = new System.Drawing.Point(41, 22);
            this.LblTime.Name = "LblTime";
            this.LblTime.Size = new System.Drawing.Size(33, 13);
            this.LblTime.TabIndex = 5;
            this.LblTime.Text = "Time:";
            // 
            // ButtonEdit
            // 
            this.ButtonEdit.Location = new System.Drawing.Point(80, 67);
            this.ButtonEdit.Name = "ButtonEdit";
            this.ButtonEdit.Size = new System.Drawing.Size(102, 20);
            this.ButtonEdit.TabIndex = 4;
            this.ButtonEdit.Text = "Edit";
            this.ButtonEdit.UseVisualStyleBackColor = true;
            this.ButtonEdit.Click += new System.EventHandler(this.ButtonEdit_Click);
            // 
            // TextBoxNewValue
            // 
            this.TextBoxNewValue.Location = new System.Drawing.Point(80, 41);
            this.TextBoxNewValue.Name = "TextBoxNewValue";
            this.TextBoxNewValue.Size = new System.Drawing.Size(102, 20);
            this.TextBoxNewValue.TabIndex = 3;
            // 
            // TextBoxTime
            // 
            this.TextBoxTime.Location = new System.Drawing.Point(80, 15);
            this.TextBoxTime.Name = "TextBoxTime";
            this.TextBoxTime.Size = new System.Drawing.Size(102, 20);
            this.TextBoxTime.TabIndex = 0;
            // 
            // ButtonClearAll
            // 
            this.ButtonClearAll.Location = new System.Drawing.Point(359, 397);
            this.ButtonClearAll.Name = "ButtonClearAll";
            this.ButtonClearAll.Size = new System.Drawing.Size(102, 20);
            this.ButtonClearAll.TabIndex = 9;
            this.ButtonClearAll.Text = "Clear All";
            this.ButtonClearAll.UseVisualStyleBackColor = true;
            this.ButtonClearAll.Click += new System.EventHandler(this.ButtonClearAll_Click);
            // 
            // GrpBoxSearch
            // 
            this.GrpBoxSearch.Controls.Add(this.ListBoxResults);
            this.GrpBoxSearch.Controls.Add(this.TextBoxSearch);
            this.GrpBoxSearch.Controls.Add(this.btnSearch);
            this.GrpBoxSearch.Location = new System.Drawing.Point(241, 11);
            this.GrpBoxSearch.Name = "GrpBoxSearch";
            this.GrpBoxSearch.Size = new System.Drawing.Size(220, 216);
            this.GrpBoxSearch.TabIndex = 10;
            this.GrpBoxSearch.TabStop = false;
            this.GrpBoxSearch.Text = "Search";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(472, 427);
            this.Controls.Add(this.GrpBoxSearch);
            this.Controls.Add(this.ButtonClearAll);
            this.Controls.Add(this.GrpBoxEdit);
            this.Controls.Add(this.ListBoxSort);
            this.Controls.Add(this.btnSortInteractions);
            this.Controls.Add(this.ListBoxInteractions);
            this.Controls.Add(this.btnGetInteractions);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Astronomical Processing";
            this.GrpBoxEdit.ResumeLayout(false);
            this.GrpBoxEdit.PerformLayout();
            this.GrpBoxSearch.ResumeLayout(false);
            this.GrpBoxSearch.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnGetInteractions;
        private System.Windows.Forms.ListBox ListBoxInteractions;
        private System.Windows.Forms.Button btnSortInteractions;
        private System.Windows.Forms.ListBox ListBoxSort;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox TextBoxSearch;
        private System.Windows.Forms.ListBox ListBoxResults;
        private System.Windows.Forms.GroupBox GrpBoxEdit;
        private System.Windows.Forms.TextBox TextBoxTime;
        private System.Windows.Forms.Button ButtonEdit;
        private System.Windows.Forms.TextBox TextBoxNewValue;
        private System.Windows.Forms.Label LblNewValue;
        private System.Windows.Forms.Label LblTime;
        private System.Windows.Forms.Button ButtonClearAll;
        private System.Windows.Forms.GroupBox GrpBoxSearch;
    }
}

