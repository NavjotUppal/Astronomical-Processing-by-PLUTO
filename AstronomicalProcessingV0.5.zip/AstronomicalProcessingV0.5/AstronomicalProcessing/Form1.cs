﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AstronomicalProcessing
{

    public partial class Form1 : Form
    {
        // Parallel array for Neutrino Interactions in chronological order Stu
        int[] neutrinoChrono = new int[24];
        // Parallel array for time periods in chronological order Stu
        string[] timePeriodChrono = new string[24];

        // Parallel array for neutrino interactions in ascending order Stu
        int[] neutrinoAscend = new int[24];
        // Parallel array for time periods in ascending order Stu
        string[] timePeriodAscend = new string[24];

        public Form1()
        {
            InitializeComponent();
        }

        // Method to sort the Neutrion Interactions in to ascending order Nav
        private void SortByNeutrinoInteraction()
        {
            for (int i = 0; i < (neutrinoAscend.Length - 1); i++)
            {
                for (int j = 0; j < (neutrinoAscend.Length - 1); j++)
                {
                    if (neutrinoAscend[j + 1] < neutrinoAscend[j])
                    {
                        int temp = neutrinoAscend[j];
                        neutrinoAscend[j] = neutrinoAscend[j + 1];
                        neutrinoAscend[j + 1] = temp;

                        // Repeating the same array sort function to the parallel timePeriod array Stu
                        string tempString = timePeriodAscend[j];
                        timePeriodAscend[j] = timePeriodAscend[j + 1];
                        timePeriodAscend[j + 1] = tempString;
                    }
                }
            }
        }

        // Method to update ListBox, takes ListBox as parameter Stu
        // listBox = which List Box to be updated
        // timePeriod = which Array to be added (chronological or ascending)
        // neutrino = which Array to be added (chronological or ascending)
        private void UpdateListBox(ListBox listBox, string[] timePeriod, int[] neutrino)
        {
            listBox.Items.Clear();
            for (int i = 0; i < 24; i++)
            {
                listBox.Items.Add(timePeriod[i] + " " + neutrino[i].ToString());
            }
        }
        // Method for generating array of neutrino interactions in chronological order Stu
        // Generates a parallel array of neutrino interactions to be sorted in ascending order later Stu
        private void GenerateNeutrinoInteractions()
        {
            int max = 100;
            int min = 10;
            Random random = new Random();
            for (int i = 0; i < 24; i++)
            {
                int temp = random.Next(min, max);
                neutrinoChrono[i] = temp;
                neutrinoAscend[i] = temp;                
            }
        }

        // Method for generating array  of time periods in chronological order Stu
        // Generates a parallel array of time periods to be sorted in ascending order later Stu
        private void GenerateTimePeriod()
        {
            int hour;
            string period;

            for (int i = 0; i < 24; i++)
            {
                hour = i % 12 + 1;
                if (i < 11 || i > 22)
                    period = "am";
                else
                    period = "pm";
                timePeriodChrono[i] = (hour + period);
                timePeriodAscend[i] = (hour + period);
            }
        }
        // Method for clicking btnGetInteractions Nav
        public void btnGetInteractions_Click(object sender, EventArgs e)
        {
            GenerateNeutrinoInteractions();
            GenerateTimePeriod();
            UpdateListBox(ListBoxInteractions, timePeriodChrono, neutrinoChrono);
        }
        // Method for clicking btnSortInteractions Nav
        public void btnSortInteractions_Click(object sender, EventArgs e)
        {
            // Clearing ListBoxSort Nav
            ListBoxSort.Items.Clear();
            // Checking if ListBoxInteractions is showing an array Nav
            if (ListBoxInteractions.Items.Count != 0)
            {
                // Sorting the array Nav
                SortByNeutrinoInteraction();
                // Showing the array in ListBoxSort Stu
                UpdateListBox(ListBoxSort, timePeriodAscend, neutrinoAscend);
            }
            // If Neutrino Interactions have not been generated and shown, show message Nav
            else if(ListBoxInteractions == null)
            {
                MessageBox.Show("Get Interactions First.");
                return;
            }
        }
        // Method for clicking btnSearch, searching the array for a specified value Nav
        private void btnSearch_Click(object sender, EventArgs e)
        {
            int midPoint;
            int lowerBound = 0;
            int upperBound = neutrinoChrono.Length - 1;
            int target;
            bool flag = false;
            if (!(Int32.TryParse(TextBoxSearch.Text, out target)))
            {
                MessageBox.Show("You must enter an integer");
                return;
            }
            while (!flag) // Check “<” or “<=” Nav
            {

                ListBoxResults.Items.Clear();
                // Find the mid-point Nav
                midPoint = (lowerBound + upperBound) / 2;
                if (upperBound < lowerBound)
                {
                    MessageBox.Show("Error Occured");
                    flag = true;
                }
                // Pause with a messagebox Nav
                // MessageBox.Show("Low:" + lowBound + " Mid:" + mid + Nav
                //  " High:" + highBound); Nav
                if (neutrinoAscend[midPoint] == target)
                {
                    // Target has been found Nav
                    ListBoxResults.Items.Add(timePeriodAscend[midPoint] + " " + neutrinoAscend[midPoint]);

                    // Checking if value after also equal to target Stu
                    int i = 1;
                    bool checkAfter = false;

                    while (!checkAfter)
                    {
                        if (midPoint + i < 24 && neutrinoAscend[midPoint + i] == target)
                        {
                            ListBoxResults.Items.Add(timePeriodAscend[midPoint + i] + " " + neutrinoAscend[midPoint + i]);
                            i++;
                        }
                        // If the check shows that the value after is not the same, checkAfter becomes true and ends the loop Stu
                        else
                            checkAfter = true;
                    }

                    i = 1;
                    bool checkBefore = false;

                    // Checking if value before also equal to target Stu
                    while (!checkBefore)
                    {
                        if (midPoint - i >= 0 && neutrinoAscend[midPoint - i] == target)
                        {
                            ListBoxResults.Items.Add(timePeriodAscend[midPoint - i] + " " + neutrinoAscend[midPoint - i]);
                            i++;
                        }
                        // If the check shows that the value before is not the same, checkBefore becomes false and ends the loop Stu
                        else
                            checkBefore = true;
                    }
                    return;
                }
                else if (neutrinoAscend[midPoint] >= target)
                {
                    upperBound = midPoint - 1;
                }
                else
                {
                    lowerBound = midPoint + 1;
                }
            }
            MessageBox.Show("Not Found, try again.");
        }

        // Method for editing the array Stu
        private void ButtonEdit_Click(object sender, EventArgs e)
        {
            // Takes the string as the time from TextBoxTime Stu
            string time = TextBoxTime.Text;
            // Takes the string as the new value from TextBoxNewValue and converts it to an integer Stu
            int newValue = int.Parse(TextBoxNewValue.Text);
            for (int i = 0; i < 24; i++)
            {
                // Iterating through the time periods in chronological order Stu
                // Looking for the time that has been entered Stu
                if (timePeriodChrono[i] == time)
                {
                    // Editing to the new value Stu
                    neutrinoChrono[i] = newValue;
                    // Immediatelly updating the ListBoxInteractions Stu
                    UpdateListBox(ListBoxInteractions, timePeriodChrono, neutrinoChrono);
                    // Coping the arrays so that the Ascending arrays match the Chronological arrays Stu
                    Array.Copy(neutrinoChrono, neutrinoAscend, 24);
                    Array.Copy(timePeriodChrono, timePeriodAscend, 24);
                    
                    // If there are items showing in the ListBoxSort...
                    if(ListBoxSort.Items.Count != 0)
                    {
                        // it will sort new lists...
                        SortByNeutrinoInteraction();
                        // and update the ListBoxSort Stu
                        UpdateListBox(ListBoxSort, timePeriodAscend, neutrinoAscend);
                    }
                }    
            }
        }
        private void ButtonClearAll_Click(object sender, EventArgs e)
        {
            // Clearing all of the List Boxes, Text Boxes Stu
            ListBoxInteractions.Items.Clear();
            ListBoxSort.Items.Clear();
            ListBoxResults.Items.Clear();
            TextBoxNewValue.Clear();
            TextBoxTime.Clear();
            TextBoxSearch.Clear();
            // Resetting all of the arrays to their original values of 0 and null Stu
            for (int i = 0; i < 24; i++)
            {
                neutrinoChrono[i] = 0;
                neutrinoAscend[i] = 0;
                timePeriodChrono[i] = null;
                timePeriodAscend[i] = null;
            }
        }
    }
}

